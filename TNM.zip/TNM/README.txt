
*** ATTENZIONE ***
Ci sono differenze tra le versioni web e compilata, sia a livello si stile che di software.
Se si devono apportare modifiche partire dall'ultima versione sviluppata per la piaffaroma di interesse.

Esempi:
 _ in fix-style.js viene settata di default la classe per Safari
